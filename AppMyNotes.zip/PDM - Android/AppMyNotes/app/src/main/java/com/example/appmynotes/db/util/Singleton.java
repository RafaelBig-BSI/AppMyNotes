package com.example.appmynotes.db.util;

import com.example.appmynotes.db.bean.Lembrete;

import java.util.ArrayList;
import java.util.List;

public class Singleton {

    static public List<Lembrete> listaDados = new ArrayList<>();

    private Singleton()
    {}
}
