package com.example.appmynotes;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.example.appmynotes.db.bean.Lembrete;
import com.example.appmynotes.db.dal.LembreteDAL;
import com.example.appmynotes.db.util.Singleton;

public class NovaAnotacao extends AppCompatActivity {

    private TextView tvTitulo, tvTexto, tvPrioridade;
    private EditText ptTitulo, ptTexto, ptPrioridade;
    private Button btCriar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nova_anotacao);

        tvTitulo = findViewById(R.id.tvTitulo);
        tvTexto = findViewById(R.id.tvTexto);
        tvPrioridade = findViewById(R.id.tvPrioridade);

        ptTitulo = findViewById(R.id.ptTitulo);
        ptTexto = findViewById(R.id.ptTexto);
        ptPrioridade = findViewById(R.id.ptPrioridade);

        btCriar = findViewById(R.id.btCriar);

        btCriar.setOnClickListener(v->{armazenarAnotacao();});
    }

    private void armazenarAnotacao()
    {
        Lembrete lembrete = new Lembrete(ptTitulo.getText().toString(),
                ptTexto.getText().toString(),
                ptPrioridade.getText().toString());


        Singleton.listaDados.add(lembrete);
        if(Singleton.listaDados.size() > 0)
        {
            LembreteDAL lembDAL = new LembreteDAL(this);
            lembDAL.salvar(lembrete);
            Toast.makeText(this, "Lembrete armazenado com SUCESSO!", Toast.LENGTH_LONG).show();
        }
        else
        {
            Toast.makeText(this, "Erro ao salvar!", Toast.LENGTH_LONG).show();
        }

    }
}