package com.example.appmynotes;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.TextView;

import com.example.appmynotes.db.bean.Lembrete;
import com.example.appmynotes.db.dal.LembreteDAL;

import java.util.List;

public class InformacoesActivity extends AppCompatActivity {

    TextView tvInfoTitulo, tvInfoTexto, tvInfoPrioridade;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_informacoes);

        tvInfoTitulo = findViewById(R.id.tvInfoTitulo);
        tvInfoTexto = findViewById(R.id.tvInfoTexto);
        tvInfoPrioridade = findViewById(R.id.tvInfoPrioridade);

        Intent intent = getIntent();
        int pos = intent.getIntExtra("posicao", 0);
        LembreteDAL dal = new LembreteDAL(this);

        List<Lembrete> lista_lembrete = dal.get("");
        Lembrete lembrete = lista_lembrete.get(pos);

        tvInfoTitulo.setText(lembrete.getTitulo());
        tvInfoTexto.setText(lembrete.getTexto());
        tvInfoPrioridade.setText(lembrete.getPrioridade());

        if(lembrete.getPrioridade().equalsIgnoreCase("alta"))
        {
            int red = Color.parseColor("#FF0000");
            tvInfoPrioridade.setTextColor(red);
        }

        if(lembrete.getPrioridade().equalsIgnoreCase("baixa"))
        {
            int black = Color.parseColor("#000000");
            tvInfoPrioridade.setTextColor(black);
        }

        if(lembrete.getPrioridade().equalsIgnoreCase("normal"))
        {
            int blue = Color.parseColor("#0000FF");
            tvInfoPrioridade.setTextColor(blue);
        }
    }
}