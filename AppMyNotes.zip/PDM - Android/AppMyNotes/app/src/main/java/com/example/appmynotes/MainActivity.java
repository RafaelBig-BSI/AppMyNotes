package com.example.appmynotes;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.appmynotes.db.bean.Lembrete;
import com.example.appmynotes.db.dal.LembreteDAL;
import com.example.appmynotes.db.util.LembreteAdapter;
import com.example.appmynotes.db.util.Singleton;

import java.util.Comparator;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private ListView listView;
    private LembreteAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.listView);

        LembreteDAL lembDAL = new LembreteDAL(this);
        List<Lembrete> listaLemb = lembDAL.get("");
        adapter = new LembreteAdapter(this, R.layout.item_listview, listaLemb);
        listView.setAdapter(adapter);

        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {

               List<Lembrete> aux =  lembDAL.get("");
               Lembrete lembrete = aux.get(i);
               lembDAL.apagar(lembrete.getId());

               //Atualizando a tela
               List<Lembrete> listaLemb = lembDAL.get("");
                adapter = new LembreteAdapter(MainActivity.this, R.layout.item_listview, listaLemb);
                listView.setAdapter(adapter);
               return true;
            }
        });

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                Intent intent = new Intent(MainActivity.this, InformacoesActivity.class);
                intent.putExtra("posicao",i);
                startActivity(intent);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(@NonNull Menu menu) {

        MenuInflater inflater =getMenuInflater();
        inflater.inflate(R.menu.menu_principal, menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId())
        {
            case R.id.itFechar: finish(); break;

            case R.id.itNovo:
                Intent intent = new Intent(this, NovaAnotacao.class);
                startActivity(intent); break;

            case R.id.itOrdem: ordenacao_alfabetica(); break;

            case R.id.itPrioridade: ordenar_prioridade(); break;

        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onPostResume() {
        super.onPostResume();

        LembreteDAL lembDAL = new LembreteDAL(this);
        List<Lembrete> listaLemb = lembDAL.get("");
        adapter = new LembreteAdapter(MainActivity.this, R.layout.item_listview, listaLemb);
        listView.setAdapter(adapter);
    }

    public void ordenacao_alfabetica()
    {
        LembreteDAL lembDAL = new LembreteDAL(this);
        List<Lembrete> lista_lembretes = lembDAL.get("");

        lista_lembretes.sort(new Comparator<Lembrete>() {
            @Override
            public int compare(Lembrete lemb1, Lembrete lemb2) {
                return (lemb1.getTitulo().compareTo(lemb2.getTitulo()));
            }
        });

        adapter = new LembreteAdapter(MainActivity.this, R.layout.item_listview, lista_lembretes);
        listView.setAdapter(adapter);
        adapter.notifyDataSetChanged();
    }

    public void ordenar_prioridade()
    {
        LembreteDAL lembDAL = new LembreteDAL(this);
        List<Lembrete> lista_lembretes = lembDAL.get("");

        lista_lembretes.sort(new Comparator<Lembrete>() {
            @Override
            public int compare(Lembrete lemb1, Lembrete lemb2) {
                return (lemb1.getPrioridade().compareTo(lemb2.getPrioridade()));
            }
        });

        adapter = new LembreteAdapter(MainActivity.this, R.layout.item_listview, lista_lembretes);
        listView.setAdapter(adapter);
        adapter.notifyDataSetChanged();
    }
}