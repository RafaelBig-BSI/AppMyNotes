package com.example.appmynotes.db.dal;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.widget.Toast;

import com.example.appmynotes.db.bean.Lembrete;
import com.example.appmynotes.db.util.Conexao;

import java.util.ArrayList;

public class LembreteDAL
{
    private Conexao con;
    private final String TABLE="lembrete";

    public LembreteDAL(Context context) {
        con = new Conexao(context);
        try {
            con.conectar();
        }
        catch(Exception e)
        {
            Toast.makeText(context,e.getMessage(),Toast.LENGTH_LONG).show();
        }
    }

    public boolean salvar(Lembrete lembrete)
    {
        ContentValues dados=new ContentValues();
        dados.put("lemb_titulo",lembrete.getTitulo());
        dados.put("lemb_texto", lembrete.getTexto());
        dados.put("lemb_prioridade", lembrete.getPrioridade());

        return con.inserir(TABLE,dados)>0;
    }
    public boolean alterar(Lembrete lembrete)
    {
        ContentValues dados=new ContentValues();
        dados.put("lemb_id",lembrete.getId());
        dados.put("lemb_titulo",lembrete.getTitulo());
        return con.alterar(TABLE,dados,"lemb_id="+lembrete.getId())>0;
    }

    public boolean apagar(long chave)
    {
        return con.apagar(TABLE,"lemb_id="+chave)>0;
    }

    public Lembrete get(int id)
    {
        Lembrete lembrete = null;
        Cursor cursor=con.consultar("select * from "+TABLE+" where lemb_id="+id);
        if(cursor.moveToFirst())
            lembrete=new Lembrete(cursor.getInt(0),cursor.getString(1), cursor.getString(2), cursor.getString(3));
        cursor.close();;
        return lembrete;
    }
    public ArrayList<Lembrete> get(String filtro)
    {   ArrayList <Lembrete> objs = new ArrayList();
        String sql="select * from "+TABLE;
        if (!filtro.equals(""))
            sql+=" where "+filtro;

        Cursor cursor=con.consultar(sql);
        if(cursor.moveToFirst())
            while (!cursor.isAfterLast()) {
                objs.add(new Lembrete(cursor.getInt(0),cursor.getString(1), cursor.getString(2), cursor.getString(3)));
                cursor.moveToNext();
            }
        cursor.close();;
        return objs;
    }
}
