package com.example.appmynotes.db.util;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.appmynotes.R;
import com.example.appmynotes.db.bean.Lembrete;

import java.util.List;

public class LembreteAdapter extends ArrayAdapter<Lembrete>
{
    private  int layout;

    public LembreteAdapter(@NonNull Context context, int resource, @NonNull List<Lembrete> objects)
    {
        super(context,resource,objects);

        layout = resource; // guardar a informação
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        if(convertView == null)
        {
            LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(this.layout, parent, false);
        }

        TextView tvTitulo2 = (TextView) convertView.findViewById(R.id.tvTitulo2);

        Lembrete item = getItem(position);
        tvTitulo2.setText(item.getTitulo());

        if(item.getPrioridade().equalsIgnoreCase("alta"))
        {
            int red = Color.parseColor("#FF0000");
            int white = Color.parseColor("#FFFFFF");
            tvTitulo2.setTextColor(white);
            convertView.setBackgroundColor(red);
        }

        if(item.getPrioridade().equalsIgnoreCase("baixa"))
        {
            int yellow = Color.parseColor("#FFFF00");
            int black = Color.parseColor("#000000");
            tvTitulo2.setTextColor(black);
            convertView.setBackgroundColor(yellow);
        }

        if(item.getPrioridade().equalsIgnoreCase("normal"))
        {
            int blue = Color.parseColor("#0000FF");
            int white = Color.parseColor("#FFFFFF");
            tvTitulo2.setTextColor(white);
            convertView.setBackgroundColor(blue);
        }

        return convertView;
    }
}
