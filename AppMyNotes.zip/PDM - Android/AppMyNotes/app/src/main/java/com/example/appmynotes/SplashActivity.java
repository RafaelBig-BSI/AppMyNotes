package com.example.appmynotes;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.ImageView;

public class SplashActivity extends AppCompatActivity {
    ImageView imageView;
    Handler handler = new Handler();
    Runnable r;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        handler.postDelayed(r = () -> {entrar();},2000); //Entra na tela principal apos 2 segundos

        imageView = findViewById(R.id.imageView);
        imageView.setOnClickListener(e -> {entrar();});
    }

    private void entrar()
    {
        handler.removeCallbacks(r); //destrói a Thread atual
        Intent intent = new Intent(this,MainActivity.class);
        startActivity(intent);
        finish();
    }
}