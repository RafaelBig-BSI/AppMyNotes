package com.example.appmynotes.db.bean;

public class Lembrete
{
    private int id;
    private String titulo, texto, prioridade;

    public Lembrete(){this(0,"","","");}

    public Lembrete(String titulo){this(0,titulo,"","");}

    public Lembrete(int id, String titulo, String texto, String prioridade) {
        this.id = id;
        this.titulo = titulo;
        this.texto = texto;
        this.prioridade = prioridade;
    }

    public Lembrete(String titulo, String texto, String prioridade) {
        this.titulo = titulo;
        this.texto = texto;
        this.prioridade = prioridade;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getTexto() {
        return texto;
    }

    public void setTexto(String texto) {
        this.texto = texto;
    }

    public String getPrioridade() {
        return prioridade;
    }

    public void setPrioridade(String prioridade) {
        this.prioridade = prioridade;
    }

    @Override
    public String toString() {
        return "Titulo: " + titulo + ", " +
                "Texto: " + texto + ", " +
                "Prioridade: " + prioridade;
    }
}
